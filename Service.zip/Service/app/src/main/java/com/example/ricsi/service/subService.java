package com.example.ricsi.service;

import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

/**
 * Created by Ricsi on 2016.05.14..
 */
public class subService extends android.app.Service {

    final class theThread implements Runnable{
        int serviceID;

        theThread(int serviceID) {
            this.serviceID = serviceID;
        }

        @Override
        public void run() {
            synchronized (this){
                try {
                    wait(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                stopSelf(serviceID);
            }
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(subService.this, "Service started", Toast.LENGTH_SHORT).show();
        Thread thread = new Thread(new theThread(startId));
        thread.start();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        Toast.makeText(subService.this, "Service stopped", Toast.LENGTH_SHORT).show();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
