package com.example.ricsi.file_io;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.editText)EditText editText;
    @BindView(R.id.textView)TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
    }
    public void clickWrite(View view){
        String mytext = editText.getText().toString();
        try {
            FileOutputStream fileOutputStream = openFileOutput("MY_TEXT.txt", MODE_PRIVATE);
            fileOutputStream.write(mytext.getBytes());
            fileOutputStream.close();
            Toast.makeText(MainActivity.this, "Text saved", Toast.LENGTH_SHORT).show();
            editText.setText("");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public void clickRead(View view){
        try {
            FileInputStream fileInput = openFileInput("MY_TEXT.txt");
            InputStreamReader inputReader = new InputStreamReader(fileInput);
            BufferedReader buffer = new BufferedReader(inputReader);
            StringBuffer stringBuffer = new StringBuffer();
            String lines;
            while ((lines = buffer.readLine())!=null){
                stringBuffer.append(lines+"\n");
            }
            textView.setText(stringBuffer.toString());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
