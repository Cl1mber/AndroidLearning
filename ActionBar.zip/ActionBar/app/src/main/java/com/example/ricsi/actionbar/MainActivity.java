package com.example.ricsi.actionbar;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar myTool = (Toolbar)findViewById(R.id.mytool);
        setSupportActionBar(myTool);
        myTool.setLogo(R.mipmap.ic_launcher);

    }

    public void toSecond(View view){
        Intent intent = new Intent(MainActivity.this, Second.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.toolbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.antenna:
                Toast.makeText(MainActivity.this, "Antenna is selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.build:
                Toast.makeText(MainActivity.this, "Builder is selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.gavel:
                Toast.makeText(MainActivity.this, "Gavel is selected", Toast.LENGTH_SHORT).show();
                return true;
            default:
                Toast.makeText(MainActivity.this, "Don't know what is selected", Toast.LENGTH_SHORT).show();
                return super.onOptionsItemSelected(item);
        }
    }
}
