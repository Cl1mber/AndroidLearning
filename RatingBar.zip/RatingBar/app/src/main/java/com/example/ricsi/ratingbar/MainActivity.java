package com.example.ricsi.ratingbar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.ratingBar) RatingBar rate;
    @BindView(R.id.button) Button button;
    @BindView(R.id.textView) TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        ratingListener();
        clickListener();
    }

    public void ratingListener(){
        rate.setOnRatingBarChangeListener(
                new RatingBar.OnRatingBarChangeListener() {
                    @Override
                    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                        text.setText(String.valueOf(rating));
                    }
                }
        );
    }
@OnClick(R.id.button)
    public void clickListener(){

                        Toast.makeText(MainActivity.this, String.valueOf(rate.getRating()), Toast.LENGTH_SHORT).show();
                    }
}
