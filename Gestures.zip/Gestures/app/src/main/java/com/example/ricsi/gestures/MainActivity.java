package com.example.ricsi.gestures;

import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener{

    @BindView(R.id.textView) TextView text;
    private GestureDetectorCompat GestureDetect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        GestureDetect = new GestureDetectorCompat(this, this);
        GestureDetect.setOnDoubleTapListener(this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        GestureDetect.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        text.setText("Single tap"+e.toString());
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        text.setText("Double tap one"+e.toString());
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        text.setText("Double tap two"+e.toString());
        return false;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        text.setText("Down"+e.toString());
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {
        text.setText("Press"+e.toString());

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        text.setText("Tap up"+e.toString());
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        text.setText("Scroll"+e1.toString()+e2.toString());
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {
        text.setText("LongPress"+e.toString());

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        text.setText("Fling"+e1.toString()+e2.toString());
        return false;
    }
}
