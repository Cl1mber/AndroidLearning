package com.example.ricsi.explicit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SecondInAppOne extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_in_app_one);
    }
}
