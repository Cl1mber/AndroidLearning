package com.example.ricsi.seekbar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.textView) TextView text;
    @BindView(R.id.seekBar) SeekBar seek;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        seekBar();
    }

    public void seekBar(){
        text.setText("Covered: "+seek.getProgress()+" / "+seek.getMax());
        seek.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    int prog_value;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        prog_value = progress;
                        text.setText("Covered: "+progress+" / "+seek.getMax());
                        Toast.makeText(MainActivity.this, "In progress...", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                        Toast.makeText(MainActivity.this, "Start seeking", Toast.LENGTH_SHORT).show();

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        text.setText("Covered: "+prog_value+" / "+seek.getMax());
                        Toast.makeText(MainActivity.this, "Stopped", Toast.LENGTH_SHORT).show();

                    }
                }
        );
    }
}
