package com.example.ricsi.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;

public class Login extends AppCompatActivity {
    @BindView(R.id.button) Button button;
    @BindView(R.id.pass) EditText password;
    @BindView(R.id.user) EditText username;
    @BindView(R.id.attempt) TextView attempts;
    int counter = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        loginMethod();
    }

    public void loginMethod(){
        attempts.setText(Integer.toString(counter));
        button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (username.getText().toString().equals("valaki") && password.getText().toString().equals("pass12")){
                            Toast.makeText(Login.this, "Beléphetsz", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent("com.example.ricsi.login.User");
                            startActivity(intent);
                        }else{
                            counter--;
                            attempts.setText(Integer.toString(counter));
                            Toast.makeText(Login.this, "Sajnos elrontottad", Toast.LENGTH_SHORT).show();
                            if (counter == 0){
                                button.setEnabled(false);
                            }
                        }
                    }
                }
        );
    }
}
