package com.example.ricsi.clock;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.AnalogClock;
import android.widget.Button;
import android.widget.DigitalClock;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.analogClock) AnalogClock analog;
    @BindView(R.id.digitalClock) DigitalClock digit;
    @BindView(R.id.button) Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

    }
    @Override
    protected void onResume(){
    super.onResume();
    switchClock();
}
    @OnClick(R.id.button)
    public void switchClock(){
        if (digit.getVisibility() == DigitalClock.GONE){
            digit.setVisibility(DigitalClock.VISIBLE);
            analog.setVisibility(AnalogClock.GONE);
        }else{
            analog.setVisibility(AnalogClock.VISIBLE);
            digit.setVisibility(DigitalClock.GONE);
        }
    }
}
