package com.example.ricsi.checkbox;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.checkBox) CheckBox check1;
    @BindView(R.id.checkBox2) CheckBox check2;
    @BindView(R.id.checkBox3) CheckBox check3;
    @BindView(R.id.button) Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        addListenerOnButton();
        addListenerOnCheckBox3(check3);
        addListenerOnCheckBox(check1);
        addListenerOnCheckBox2(check2);
    }

    @OnClick(R.id.checkBox3)
    public void addListenerOnCheckBox(View v){

                        if (((CheckBox)v).isChecked()){
                            Toast.makeText(MainActivity.this, "Dog is selected", Toast.LENGTH_SHORT).show();
                        }
    }

    @OnClick(R.id.checkBox2)
    public void addListenerOnCheckBox2(View v){

                        if (((CheckBox)v).isChecked()) {
                            Toast.makeText(MainActivity.this, "Cat is selected", Toast.LENGTH_SHORT).show();
                        }

    }

    @OnClick(R.id.checkBox3)
    public void addListenerOnCheckBox3(View v) {

        if (((CheckBox) v).isChecked()) {
            Toast.makeText(MainActivity.this, "Cow is selected", Toast.LENGTH_SHORT).show();

        }
    }

    @OnClick(R.id.button)
    public void addListenerOnButton(){
                        StringBuffer result = new StringBuffer();
                        result.append("Dog : ").append(check1.isChecked());
                        result.append("\nCat : ").append(check2.isChecked());
                        result.append("\nCow : ").append(check3.isChecked());
                        Toast.makeText(MainActivity.this, result.toString(), Toast.LENGTH_LONG).show();
    }
}
