package com.example.ricsi.browser;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.webView) WebView viewer;
    @BindView(R.id.button) Button button;
    @BindView(R.id.editText) EditText www;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        openUrl();
    }


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_main, container, false);
        ButterKnife.bind(this, view);
        // TODO Use fields...
        return view;
    }


    public void openUrl(){
        button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String url = www.getText().toString();
                        viewer.getSettings().setLoadsImagesAutomatically(true);
                        viewer.getSettings().setJavaScriptEnabled(true);
                        viewer.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
                        viewer.loadUrl(url);
                    }
                }
        );


    }

}
