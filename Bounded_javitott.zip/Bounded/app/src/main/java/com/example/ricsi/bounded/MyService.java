package com.example.ricsi.bounded;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.annotation.Nullable;

import java.io.FileDescriptor;
import java.util.Random;

/**
 * Created by Ricsi on 2016.05.14..
 */
public class MyService extends Service {

    private final IBinder mbinder = new localBinder();
    private final Random generator = new Random();




    public class localBinder extends Binder{
        MyService getService(){
            return MyService.this;
        }
    }

    public MyService() {
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {

        return mbinder;
    }

    public int getRandom(){
        return generator.nextInt(2000);
    }
}
