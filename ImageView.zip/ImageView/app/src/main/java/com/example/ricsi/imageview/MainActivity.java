package com.example.ricsi.imageview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.button)
    Button button;
    @BindView(R.id.imageView)
    ImageView image;
    private int index;
    private int[] images = {R.mipmap.cirquit, R.mipmap.cirquit2, R.mipmap.tree};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        switchImage();
    }
    @OnClick(R.id.button)
    public void switchImage(){
        index++;
        index %= images.length;
        image.setImageResource(images[index]);

    }

}
